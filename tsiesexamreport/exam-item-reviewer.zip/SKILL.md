---
name: exam-item-reviewer
description: Review elementary and secondary school exam papers against a 38-point item review rubric. Use when the user asks to review exam questions (審題、檢核考題、試題檢核、命題自評、審題複核), check test items for flaws, or generate a list of exam items needing revision with violated rubric dimensions, reasons, and suggested revisions.
---
# Exam Item Reviewer

Review school exam papers against the 38-point Item Review Rubric (命題審題檢核表38項指標) and output a focused, exception-based diagnostic list of items needing revision.

## When to Use

- The user uploads or pastes an exam paper (試卷/考題) and asks for item review (審題/檢核考題).
- A teacher (as test creator or reviewer) wants to identify flawed questions, violated rubric criteria, and concrete revision suggestions.

## Reference Files

Before performing an analysis, read the rubric reference files if detailed explanations or examples of the 38 indicators are needed:

- `references/checklist_form.docx` - The blank 38-item review checklist form.
- `references/rubric_guidelines.docx` - Detailed explanations and examples (✓/✗) for all 38 indicators.

## Workflow

### Step 1: Confirm Grade Level and Subject

Before analyzing the exam questions, verify that you know:

1. **Grade level (學生年級)** (e.g., 國小三年級, 國中八年級) - Essential for judging vocabulary appropriateness, phonetic notation (注音) requirements for grades 1-3, and cognitive depth.
2. **Subject (科目/領域)** (e.g., 國語文, 數學, 自然科學, 社會) - Essential for applying subject-specific criteria.

If the grade level or subject is already stated in the exam header or user prompt, acknowledge them and proceed directly to Step 2. If either is missing and cannot be inferred from the exam paper, ask the user briefly to confirm before analyzing.

### Step 2: Analyze Exam Items Against the 38 Indicators

Evaluate the exam paper thoroughly using the 38 indicators grouped into 10 categories:

- **一、目標導向與內容效度 (1-6)**: Alignment with curriculum, grade-level ability, scope, balanced distribution, and point allocation.
- **二、認知層次、題型與鑑別力 (7-10)**: Understanding/application focus, Bloom's cognitive distribution, at least 3 item types without cross-section concept repetition, and differentiation.
- **三、素養導向 (11-15)**: Competency-based items (>=30 points across >=2 sections), authentic and necessary context (cannot be answered if context is stripped), problem-solving over rote memorization, appropriate sub-item count vs. passage length, source citation, and inclusion of non-multiple-choice items in question sets.
- **四、文字敘述 (16-19)**: Clear and unambiguous wording (one question per item), concise text without irrelevant info or typos/punctuation errors, age-appropriate wording (avoiding vague terms like 「最正確的」「不一定」), positive phrasing preferred (negative words like **<ins>不是</ins>** must be bolded and double-underlined; no double negatives).
- **五、選擇題與答案 (20-24)**: Complete stem with grammatically consistent options and a single best answer, plausible distractors of similar length without overlapping ranges, no clue leakage or absolute terms (「以上皆是/皆非」「一定」「絕不」), balanced answer key distribution without patterns, accurate answer key and scoring rubrics for open-ended items.
- **六、其他題型 (25-27)**: True/False tests one concept per item; Fill-in-the-blank has <=2 blanks with a single unique answer; Phonetic/character items placed in sentence/context; Matching items have more options than prompts and state whether options can be reused; Open-ended/essay items specify concrete criteria and partial credit.
- **七、難度、配分與時間 (28-30)**: Reasonable difficulty (Easy:Medium:Hard ~ 3:5:2, no trick/nitpicky items), reasonable point weighting totaling exactly 100 points, appropriate length for test duration.
- **八、公平與獨立 (31-32)**: Free of gender/regional/cultural/socioeconomic bias (local context provides all needed info), no item interdependence (母子效應 - one item giving away or depending on another item's answer).
- **九、原創與保密 (33-34)**: Avoid direct copying of commercial test banks or workbook items without transformation.
- **十、試卷格式 (35-38)**: Complete header info, appropriate font (標楷體, phonetic notation for grades 1-3), continuous numbering and clear section point labels, neat layout without split items across pages.

### Step 3: Output Only Items Needing Revision

Do NOT output the full 38-item table or list items that pass inspection. Provide a clean, copy-paste-ready list containing ONLY the questions or global formatting/structural issues that require revision.

Use the following 4-field format for each flagged item:

#### 【題號／區塊標示】（例：第二大題 選擇題第 4 題，或「全卷結構／卷頭格式」）

- **須修正向度**：列出違反的指標編號與名稱（若同一題違反多個向度，請並列，例如：`指標 19【文字敘述】否定字眼未加粗加雙底線`、`指標 22【選擇題與答案】使用絕對字眼或「以上皆是」`）
- **修正原因**：具體指出原題幹、選項或配分哪裡出了問題（引用原題文字說明）。
- **建議修正方式**：直接提供修改後的具體題幹、選項或調整方案，方便命題或審題教師直接複製貼上。

If an indicator requires external context not provided by the user (e.g., textbook lesson scope, teacher trial-run time), briefly add a one-line reminder at the very end for the teacher to self-check those specific items rather than guessing.
